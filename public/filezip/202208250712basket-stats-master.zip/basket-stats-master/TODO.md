Todo
====

* Unified help dialog with tree wiev.
* All dialogs and windows should have main window for parent (so they are centered over it).
* All dialogs should have titles and Ok, Cancel and help buttons.
* Game was not saved..: all the data since last save will be lost.? + cancel option?
* Configure stat should be showing shot values - or even aloved to be changed - the unscored ones... 
* Popup help at stat selection, wider positioning.
* Rebounds in less grey color, to-s also little grayed ?
* Text on stdout.
* Save as should remember last folder !
* Status bar or separate window/frame with last action/actions.
