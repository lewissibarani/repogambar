package si.gto76.basketstats.coreclasses;

public interface HasStats {
	public int get(Stat stat);
}
