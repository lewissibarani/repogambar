package si.gto76.basketstats.coreclasses;

public interface HasName {
	public void setName(String name);
	public String getName();
}
